package tripmember.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ZipcodeDTO {
	private String zipcode;
	private String sido;
	private String sigungu;
	private String yubmyundong;
	private String ri;
	private String roadname;
	private String buildingname;
}
